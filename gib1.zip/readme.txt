# gib-react
## Visual Studio Code içersinde Terminal New Terminal diyerek "cd api" komutu ile api içerisine yerleşiyoruz ve  " json-server --watch db.json " komutu ile fake api, 3000. portta çalışmaya başlıyor.
## Tekrar New Terminal diyere cd .. komutu ile gib1 dizinine çıkarak "npm start" diyoruz. 3000. portta api çalıştığı için, (Something is already running on port 3000.
Would you like to run the app on another port instead? » (Y/n) ) uyarısı ile karşılaşıyoruz. "Y" diyerek uygulamamızın 3001. portta çalışmasına izin veriyoruz. 
