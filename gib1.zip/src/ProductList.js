import React, { Component } from "react";
import {
  Card,
  CardImg,
  CardTitle,
  CardText,
  CardSubtitle,
  CardBody,
  Container,
  Row,
  Col,
} from "reactstrap";

export default class ProductList extends Component {

  formatter = new Intl.NumberFormat("tr-TR", {
    style: "currency",
    currency: "TRY",
  });

  getPriceAfterDiscount = (product) => {
    let unitPrice = parseFloat(product.unitPrice);
    let discount = parseFloat(product.discount);
    let priceAfterDiscount = this.formatter.format(
      unitPrice - unitPrice * discount * 0.01
    );
    return priceAfterDiscount;
  };

  render() {
    return (
      <div>
        <h3>{this.props.info.title}</h3>
        <Container>
          <Row>
            {this.props.products.map((product) => (
              <Col xs={4}>
                <Card key={product.id}>
                  <CardImg
                    top
                    height="100%"
                    width="100%"
                    src={require(`./assets/${product.image}.jpg`).default}
                    alt="Product image"
                  />
                  <CardBody>
                    <CardTitle tag="h5">{product.productName}</CardTitle>
                    <CardSubtitle tag="h6" className="mb-2 text-muted">
                      {product.discount !== "" ? product.discount + "%" : ""}
                    </CardSubtitle>
                    <CardSubtitle tag="h6" className="mb-2 text-muted">
                      {product.discount !== "" ? (
                        <strike>
                          {this.formatter.format(parseFloat(product.unitPrice))}
                        </strike>
                      ) : (
                        this.formatter.format(parseFloat(product.unitPrice))
                      )}
                    </CardSubtitle>
                    <CardSubtitle tag="h6" className="mb-2 text-muted">
                      {product.discount !== ""
                        ? this.getPriceAfterDiscount(product)
                        : ""}
                    </CardSubtitle>
                    <CardText>{product.description}</CardText>
                  </CardBody>
                </Card>
              </Col>
            ))}
          </Row>
        </Container>
      </div>
    );
  }
}
