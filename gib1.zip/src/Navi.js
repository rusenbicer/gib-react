import React, { Component } from 'react';

export default class Navi extends Component {

    render() {
        return (
            <div>
                <h2>Navi Component</h2>
            </div>
        );
    }
}
